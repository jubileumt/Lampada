//dom

const Lampada = document.querySelector('#lampada');
const btnLigar = document.querySelector('#ligar');
const btnApagar = document.querySelector('#apagar');

//eventos

btnLigar.addEventListener('click',acender);

btnApagar.addEventListener('click',apagar);

Lampada.addEventListener('dblclick',quebrar);

//funçoes

function acender(){
    Lampada.src="imagens/acesa.gif";
}
function apagar(){
    Lampada.src="imagens/apagada.gif";
}
function quebrar(){
    Lampada.src="imagens/quebrada.jpg";
}